﻿using Microsoft.EntityFrameworkCore;

namespace groupFileData.DataAccess
{
    public class ApplicationDbContext
    {


    }
}
