﻿using groupFileData.Models.Dtos;
using Microsoft.AspNetCore.Mvc;
using OfficeOpenXml;
using groupFileData.Services;
using System.Collections.Concurrent;

namespace groupFileData.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class FileController : ControllerBase
    {
        private readonly FileService _fileService;
        public FileController(FileService fileService)
        {
            _fileService = fileService;
        }


        [HttpPost("UploadExcel")]
        public async Task<IActionResult> UploadExcel(IFormFile file)
        {
            if (file == null || file.Length == 0)
            {
                return BadRequest("File is empty or not provided.");
            }
            // Validate file extension
            var fileExtension = Path.GetExtension(file.FileName).ToLowerInvariant();
            var allowedExtensions = new[] { ".xlsx", ".xls" };
            if (!allowedExtensions.Contains(fileExtension))
            {
                return BadRequest("Invalid file type. Only .xlsx and .xls files are allowed.");
            }

            try
            {
                var excelData = await _fileService.ReadExcelFileAsync(file);
                var resources = _fileService.MapToResources(excelData);
                var groupedData = _fileService.GroupData(resources);

                return Ok(new { excelData, groupedData });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }
         
    }
}
